import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { execSync } from 'child_process'
import { rmSync } from 'fs'
import path from 'path'

/**
 * Custom-domain LIFECYCLE against a throwaway SQLite database: claim
 * exclusivity, expired-claim reclaim, TXT verification (stubbed DNS),
 * manual hosting confirmation, primary selection, removal, and the
 * resolver + canonical helpers. Cross-tenant takeover is the critical
 * security property under test.
 */

const TEST_DB = path.resolve('/tmp/openchurch-test-domains.db')
const STUB_TTL = 60 * 60 * 1000

type Db = Awaited<ReturnType<typeof newClient>>
async function newClient() {
  const { PrismaClient } = await import('@prisma/client')
  return new PrismaClient()
}

let db: Db
let svc: typeof import('@/lib/domains/service')
let resolver: typeof import('@/lib/tenancy/resolver')
let churchA: { id: string; slug: string }
let churchB: { id: string; slug: string }
let actorUserId = ''

// DNS stub the service can use: map hostname -> TXT records.
const dnsRecords = new Map<string, string[][]>()

beforeAll(async () => {
  rmSync(TEST_DB, { force: true })
  process.env.DATABASE_URL = `file:${TEST_DB}`
  execSync('bunx prisma db push --skip-generate --accept-data-loss', {
    stdio: 'pipe',
    env: { ...process.env },
    cwd: path.resolve(__dirname, '..'),
  })
  db = await newClient()
  svc = await import('@/lib/domains/service')
  resolver = await import('@/lib/tenancy/resolver')
  churchA = await db.church.create({
    data: { slug: 'church-a', name: 'Church A', country: 'NG', plan: 'premium', settings: { create: {} } },
    select: { id: true, slug: true },
  })
  churchB = await db.church.create({
    data: { slug: 'church-b', name: 'Church B', country: 'GB', plan: 'premium', settings: { create: {} } },
    select: { id: true, slug: true },
  })
  const actorUser = await db.user.create({
    data: { email: 'domain-admin@test.dev', name: 'Domain Admin', passwordHash: 'x' },
    select: { id: true },
  })
  actorUserId = actorUser.id
})

afterAll(async () => {
  await db.$disconnect()
  rmSync(TEST_DB, { force: true })
})

// MUST be lazy: actorUserId is assigned in beforeAll — an eager object
// would capture '' at module-load time and fail the audit FK constraint.
const actor = {
  get actorUserId() {
    return actorUserId
  },
  actorEmail: 'domain-admin@test.dev',
}
const dnsStub = async (name: string) => {
  const records = dnsRecords.get(name)
  if (!records) {
    const err = new Error('not found') as NodeJS.ErrnoException
    err.code = 'ENOTFOUND'
    throw err
  }
  return records
}

describe('domain claim exclusivity', () => {
  it('church A adds a domain and receives TXT instructions', async () => {
    const res = await svc.addDomain({ churchId: churchA.id, rawDomain: 'WWW.GraceCommunity.org', ...actor })
    expect(res.ok).toBe(true)
    if (res.ok) {
      expect(res.domain.domain).toBe('www.gracecommunity.org')
      expect(res.domain.status).toBe('PENDING')
      expect(res.domain.verificationToken).toMatch(/^[0-9a-f]{64}$/)
      expect(res.domain.txtRecord?.name).toBe('_openchurch-verify.www.gracecommunity.org')
      // Store the token for later DNS stubbing.
      dnsRecords.set('_openchurch-verify.www.gracecommunity.org', [
        [`openchurch-verify=${res.domain.verificationToken}`],
      ])
    }
  })

  it('church B cannot claim the same domain while the token is valid', async () => {
    const res = await svc.addDomain({ churchId: churchB.id, rawDomain: 'www.gracecommunity.org', ...actor })
    expect(res.ok).toBe(false)
    if (!res.ok) {
      expect(res.status).toBe(409)
      expect(res.code).toBe('CLAIM_PENDING')
    }
  })

  it('church A re-adding its own PENDING domain regenerates the token (idempotent)', async () => {
    const res = await svc.addDomain({ churchId: churchA.id, rawDomain: 'www.gracecommunity.org', ...actor })
    expect(res.ok).toBe(true)
    if (res.ok) {
      expect(res.domain.verificationToken).toMatch(/^[0-9a-f]{64}$/)
      dnsRecords.set('_openchurch-verify.www.gracecommunity.org', [
        [`openchurch-verify=${res.domain.verificationToken}`],
      ])
    }
  })

  it('rejects invalid domains outright', async () => {
    for (const bad of ['notadomain', 'localhost', '8.8.8.8', 'x.vercel.app']) {
      const res = await svc.addDomain({ churchId: churchA.id, rawDomain: bad, ...actor })
      expect(res.ok).toBe(false)
    }
  })
})

describe('verification (stubbed DNS)', () => {
  let domainId = ''

  it('marks VERIFICATION_FAILED when DNS has no record yet (retryable)', async () => {
    const list = await svc.listDomains(churchA.id)
    domainId = list[0].id
    dnsRecords.delete('_openchurch-verify.www.gracecommunity.org')
    const res = await svc.verifyDomain({ churchId: churchA.id, domainId, ...actor, resolver: dnsStub })
    expect(res.ok).toBe(true)
    if (res.ok) {
      expect(res.domain.status).toBe('VERIFICATION_FAILED')
      expect(res.domain.failureReason).toContain('No TXT record')
    }
  })

  it('rejects a wrong token value (VERIFICATION_FAILED, still unverified)', async () => {
    dnsRecords.set('_openchurch-verify.www.gracecommunity.org', [['openchurch-verify=' + 'f'.repeat(64)]])
    const res = await svc.verifyDomain({ churchId: churchA.id, domainId, ...actor, resolver: dnsStub })
    expect(res.ok).toBe(true)
    if (res.ok) expect(res.domain.status).toBe('VERIFICATION_FAILED')
    // The row stays unverified — the resolver never serves it.
    const t = await resolver.resolveChurchByHost('www.gracecommunity.org')
    expect(t).toBeNull()
  })

  it('verifies when DNS carries the exact token (split character-strings too)', async () => {
    // Regenerate to get a fresh plain token (also resets the failed state),
    // then set DNS with the value split across two character-strings
    // (common for long TXT values).
    const regen = await svc.verifyDomain({ churchId: churchA.id, domainId, ...actor, resolver: dnsStub })
    expect(regen.ok).toBe(true)
    const fresh = await svc.regenerateToken({ churchId: churchA.id, domainId, ...actor })
    expect(fresh.ok).toBe(true)
    const token = fresh.ok ? fresh.domain.verificationToken! : ''
    dnsRecords.set('_openchurch-verify.www.gracecommunity.org', [
      ['openchurch-verify=', token.slice(0, 32), token.slice(32)],
    ])
    const res = await svc.verifyDomain({ churchId: churchA.id, domainId, ...actor, resolver: dnsStub })
    expect(res.ok).toBe(true)
    if (res.ok) expect(res.domain.status).toBe('VERIFIED')
  })

  it('the plain token is never stored in the database (hash only)', async () => {
    const rows = await db.churchDomain.findMany({ where: { churchId: churchA.id } })
    for (const row of rows) {
      if (row.verificationTokenHash) {
        expect(row.verificationTokenHash).toMatch(/^[0-9a-f]{64}$/)
        // None of the DNS values equal the stored hash (i.e. it is a digest).
        for (const records of dnsRecords.values()) {
          for (const r of records) expect(r.join('')).not.toBe(row.verificationTokenHash)
        }
      }
    }
  })
})

describe('hosting + primary + resolution', () => {
  let domainId = ''

  beforeAll(async () => {
    const list = await svc.listDomains(churchA.id)
    domainId = list[0].id
  })

  it('manual confirmation (self-hosted mode) marks the domain ACTIVE', async () => {
    // No VERCEL_TOKEN configured in this environment -> manual mode.
    const res = await svc.confirmManualConnection({ churchId: churchA.id, domainId, ...actor })
    expect(res.ok).toBe(true)
    if (res.ok) expect(res.domain.status).toBe('ACTIVE')
  })

  it('the resolver serves the owning church for the ACTIVE domain', async () => {
    const t = await resolver.resolveChurchByHost('www.gracecommunity.org')
    expect(t).toMatchObject({
      churchId: churchA.id,
      slug: churchA.slug,
      domain: 'www.gracecommunity.org',
      isPrimaryDomain: false, // no primary flag set yet
      primaryDomain: null,
    })
  })

  it('unrelated hosts do not resolve', async () => {
    expect(await resolver.resolveChurchByHost('unknown.example.org')).toBeNull()
    expect(await resolver.resolveChurchByHost('gracecommunity.org')).toBeNull()
  })

  it('primary selection requires ACTIVE and clears other primaries', async () => {
    const second = await svc.addDomain({ churchId: churchA.id, rawDomain: 'gracecommunity.org', ...actor })
    expect(second.ok).toBe(true)
    // Not verified yet -> cannot be primary.
    const early = await svc.setPrimaryDomain({
      churchId: churchA.id,
      domainId: second.ok ? second.domain.id : '',
      ...actor,
    })
    expect(early.ok).toBe(false)
    // Canonical origin uses the ACTIVE primary domain.
    const canon = await svc.resolveCanonicalOrigin(churchA.id, 'https://platform.example', null)
    expect(canon).toEqual({ origin: 'https://www.gracecommunity.org', isChurchDomain: true })
    expect(svc.churchCanonicalUrl(canon, churchA.slug, 'about')).toBe('https://www.gracecommunity.org/about')
  })

  it('canonical falls back to the platform origin without domains', async () => {
    const canon = await svc.resolveCanonicalOrigin(churchB.id, 'https://platform.example', null)
    expect(canon).toEqual({ origin: 'https://platform.example', isChurchDomain: false })
    expect(svc.churchCanonicalUrl(canon, churchB.slug, 'about')).toBe(
      'https://platform.example/church/church-b/about'
    )
  })
})

describe('expired pending claims are reclaimable (never silently transferred)', () => {
  it('church B can claim a domain whose PENDING claim by A has expired', async () => {
    const expired = new Date(Date.now() - 2 * STUB_TTL)
    await db.churchDomain.create({
      data: {
        churchId: churchA.id,
        domain: 'stale.example.org',
        status: 'PENDING',
        verificationTokenHash: 'x',
        tokenExpiresAt: expired,
      },
    })
    const res = await svc.addDomain({ churchId: churchB.id, rawDomain: 'stale.example.org', ...actor })
    expect(res.ok).toBe(true)
    // And it now belongs to B, not A.
    const rows = await db.churchDomain.findMany({ where: { domain: 'stale.example.org' } })
    expect(rows).toHaveLength(1)
    expect(rows[0].churchId).toBe(churchB.id)
  })
})

describe('plan entitlements gate new claims', () => {
  it('a church on the free plan cannot add domains (PLAN_LIMIT)', async () => {
    const free = await db.church.create({
      data: { slug: 'church-free', name: 'Free Church', country: 'NG', plan: 'free', settings: { create: {} } },
      select: { id: true },
    })
    const res = await svc.addDomain({ churchId: free.id, rawDomain: 'freechurch.example.org', ...actor })
    expect(res.ok).toBe(false)
    if (!res.ok) {
      expect(res.status).toBe(403)
      expect(res.code).toBe('PLAN_LIMIT')
      expect(res.error).toContain('plan')
    }
  })

  it('the limit counts connected domains and blocks the excess add', async () => {
    const paid = await db.church.create({
      data: { slug: 'church-paid', name: 'Paid Church', country: 'NG', plan: 'paid', settings: { create: {} } },
      select: { id: true },
    })
    const first = await svc.addDomain({ churchId: paid.id, rawDomain: 'paidchurch.example.org', ...actor })
    expect(first.ok).toBe(true)
    const second = await svc.addDomain({ churchId: paid.id, rawDomain: 'more.paidchurch.example.org', ...actor })
    expect(second.ok).toBe(false)
    if (!second.ok) expect(second.code).toBe('PLAN_LIMIT')
  })

  it('re-adding your own PENDING domain is idempotent even at the limit', async () => {
    const paid = await db.church.findUnique({ where: { slug: 'church-paid' }, select: { id: true } })
    const res = await svc.addDomain({ churchId: paid!.id, rawDomain: 'paidchurch.example.org', ...actor })
    expect(res.ok).toBe(true) // token refresh, not a new claim
  })
})

describe('removal lifecycle', () => {
  it('removal deletes the mapping and keeps the audit trail', async () => {
    const list = await svc.listDomains(churchA.id)
    const active = list.find((d) => d.status === 'ACTIVE')!
    const res = await svc.removeDomain({ churchId: churchA.id, domainId: active.id, ...actor })
    expect(res.ok).toBe(true)
    const after = await svc.listDomains(churchA.id)
    expect(after.find((d) => d.id === active.id)).toBeUndefined()
    const audits = await db.auditLog.findMany({
      where: { entityType: 'church_domain', action: 'domain.removed' },
    })
    expect(audits.length).toBeGreaterThanOrEqual(1)
  })

  it('cross-church removal is impossible (scoped lookup)', async () => {
    const bDomains = await svc.listDomains(churchB.id)
    expect(bDomains.length).toBeGreaterThan(0)
    const res = await svc.removeDomain({ churchId: churchA.id, domainId: bDomains[0].id, ...actor })
    expect(res.ok).toBe(false)
    if (!res.ok) expect(res.status).toBe(404)
  })
})

describe('capability gates: serverless hosting without provider integration', () => {
  // Simulate the hosted demonstration: a serverless runtime (Vercel sets
  // VERCEL=1) with NO provider credentials. The workflow must be refused
  // honestly — listing and removal stay available.
  let savedEnv: Record<string, string | undefined>

  beforeAll(() => {
    savedEnv = {
      VERCEL: process.env.VERCEL,
      VERCEL_TOKEN: process.env.VERCEL_TOKEN,
      VERCEL_PROJECT_ID: process.env.VERCEL_PROJECT_ID,
      CUSTOM_DOMAIN_MODE: process.env.CUSTOM_DOMAIN_MODE,
    }
    delete process.env.VERCEL_TOKEN
    delete process.env.VERCEL_PROJECT_ID
    delete process.env.CUSTOM_DOMAIN_MODE
    process.env.VERCEL = '1'
  })

  afterAll(() => {
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k]
      else process.env[k] = v
    }
  })

  it('adding a domain is refused with DOMAINS_UNAVAILABLE', async () => {
    const res = await svc.addDomain({ churchId: churchA.id, rawDomain: 'blocked.example.org', ...actor })
    expect(res.ok).toBe(false)
    if (!res.ok) {
      expect(res.status).toBe(403)
      expect(res.code).toBe('DOMAINS_UNAVAILABLE')
      // The refusal explains itself instead of offering impossible steps.
      expect(res.error).toMatch(/not available on this deployment/)
    }
  })

  it('verification and token regeneration are refused for existing rows', async () => {
    const list = await svc.listDomains(churchA.id)
    const pending = list.find((d) => d.status === 'PENDING')
    expect(pending).toBeDefined()
    const verify = await svc.verifyDomain({ churchId: churchA.id, domainId: pending!.id, ...actor })
    expect(verify.ok).toBe(false)
    if (!verify.ok) expect(verify.code).toBe('DOMAINS_UNAVAILABLE')
    const regen = await svc.regenerateToken({ churchId: churchA.id, domainId: pending!.id, ...actor })
    expect(regen.ok).toBe(false)
    if (!regen.ok) expect(regen.code).toBe('DOMAINS_UNAVAILABLE')
  })

  it('manual confirmation cannot fabricate hosting on serverless (verified row, no server to point at)', async () => {
    // Insert a VERIFIED row directly: on a serverless deployment there is no
    // path that legitimately reaches VERIFIED, but even this state must never
    // become ACTIVE via owner confirmation.
    const row = await db.churchDomain.create({
      data: {
        churchId: churchA.id,
        domain: 'verified-on-serverless.example.org',
        status: 'VERIFIED',
        isVerified: true,
        verificationTokenHash: 'a'.repeat(64),
        tokenExpiresAt: new Date(Date.now() + STUB_TTL),
      },
    })
    const res = await svc.confirmManualConnection({ churchId: churchA.id, domainId: row.id, ...actor })
    expect(res.ok).toBe(false)
    if (!res.ok) {
      expect(res.status).toBe(403)
      expect(res.code).toBe('DOMAINS_UNAVAILABLE')
    }
    // And automated connect is refused too.
    const connect = await svc.connectDomain({ churchId: churchA.id, domainId: row.id, ...actor })
    expect(connect.ok).toBe(false)
    await db.churchDomain.delete({ where: { id: row.id } })
  })

  it('primary selection and automated connect are refused on ACTIVE rows', async () => {
    const row = await db.churchDomain.create({
      data: {
        churchId: churchA.id,
        domain: 'active-on-serverless.example.org',
        status: 'ACTIVE',
        isVerified: true,
        provider: 'manual',
        sslStatus: 'MANAGED_BY_HOST',
      },
    })
    const setPrimary = await svc.setPrimaryDomain({ churchId: churchA.id, domainId: row.id, ...actor })
    expect(setPrimary.ok).toBe(false)
    if (!setPrimary.ok) expect(setPrimary.code).toBe('DOMAINS_UNAVAILABLE')
    // An ACTIVE row IS ownership-verified, so connect passes that gate and
    // then hits the capability gate — the honest refusal.
    const connect = await svc.connectDomain({ churchId: churchA.id, domainId: row.id, ...actor })
    expect(connect.ok).toBe(false)
    if (!connect.ok) expect(connect.code).toBe('DOMAINS_UNAVAILABLE')
    await db.churchDomain.delete({ where: { id: row.id } })
  })

  it('removal stays available (cleanup is always legitimate)', async () => {
    const list = await svc.listDomains(churchA.id)
    expect(list.length).toBeGreaterThan(0)
    const res = await svc.removeDomain({ churchId: churchA.id, domainId: list[0].id, ...actor })
    expect(res.ok).toBe(true)
    const after = await svc.listDomains(churchA.id)
    expect(after.find((d) => d.id === list[0].id)).toBeUndefined()
  })
})

describe('platform subdomain routing (wildcard DNS via PLATFORM_ROOT_DOMAIN)', () => {
  it('resolves <slug>.<root> to the church; unknown/reserved subdomains do not', async () => {
    process.env.PLATFORM_ROOT_DOMAIN = 'openchurch.test'
    try {
      // Slug subdomain → the church's site (previously DEAD CODE: the proxy
      // treated every *.root host as platform traffic).
      const t = await resolver.resolveChurchByHost('church-a.openchurch.test')
      expect(t).toMatchObject({ churchId: churchA.id, slug: 'church-a', domain: null })

      // Unknown subdomains and reserved labels fall through to the platform.
      expect(await resolver.resolveChurchByHost('nobody.openchurch.test')).toBeNull()
      expect(await resolver.resolveChurchByHost('www.openchurch.test')).toBeNull()
    } finally {
      delete process.env.PLATFORM_ROOT_DOMAIN
    }
  })

  it('isPlatformHost: root and www are platform hosts, slug subdomains are NOT', () => {
    process.env.PLATFORM_ROOT_DOMAIN = 'openchurch.test'
    try {
      expect(resolver.isPlatformHost('openchurch.test')).toBe(true)
      expect(resolver.isPlatformHost('www.openchurch.test')).toBe(true)
      // Church addresses — the proxy must attempt tenant resolution.
      expect(resolver.isPlatformHost('church-a.openchurch.test')).toBe(false)
      // Custom domains are never platform hosts.
      expect(resolver.isPlatformHost('www.gracecommunity.org')).toBe(false)
    } finally {
      delete process.env.PLATFORM_ROOT_DOMAIN
    }
  })
})
